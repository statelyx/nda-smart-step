export default function LoginPage() {
  return <div>Login Page - NDA Smart Step</div>;
}
