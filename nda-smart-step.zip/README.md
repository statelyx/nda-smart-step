# NDA Smart Step
Generated project skeleton.